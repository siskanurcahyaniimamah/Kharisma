<a href="/">
    <img src="/images/logo.svg" style="height: 30px;"/>
</a>
